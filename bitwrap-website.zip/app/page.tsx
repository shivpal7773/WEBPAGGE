import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import HeroSection from "@/components/hero-section"
import WebDevelopmentSection from "@/components/web-development-section"
import ServicesSection from "@/components/services-section"
import StatsSection from "@/components/stats-section"
import ValuesSection from "@/components/values-section"
import CtaSection from "@/components/cta-section"
import TestimonialsSection from "@/components/testimonials-section"
import ClientsSection from "@/components/clients-section"
import ContactSection from "@/components/contact-section"
import WhatsAppButton from "@/components/whatsapp-button"

export default function Home() {
  return (
    <main className="min-h-screen">
      <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b">
        <div className="container flex items-center justify-between py-4">
          <Link href="/" className="flex items-center gap-2">
            <Image src="/logo.svg" alt="Bitwrap Technologies" width={60} height={60} className="h-10 w-auto" />
            <span className="font-bold text-xl">Bitwrap</span>
            <span className="text-xs text-muted-foreground mt-auto mb-1">Technologies</span>
          </Link>
          <nav className="hidden md:flex items-center gap-8">
            <Link href="/" className="font-medium hover:text-orange-500 transition-colors">
              Home
            </Link>
            <Link href="/about-us" className="font-medium hover:text-orange-500 transition-colors">
              About Us
            </Link>
            <Link href="/services" className="font-medium hover:text-orange-500 transition-colors">
              Services
            </Link>
            <Button asChild className="bg-orange-500 hover:bg-orange-600 text-white">
              <Link href="/contact">Contact Us</Link>
            </Button>
          </nav>
        </div>
      </header>

      <HeroSection />
      <WebDevelopmentSection />
      <ServicesSection />
      <StatsSection />
      <ValuesSection />
      <CtaSection />
      <TestimonialsSection />
      <ClientsSection />
      <ContactSection />
      <WhatsAppButton />
    </main>
  )
}
