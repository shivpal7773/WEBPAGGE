import type React from "react"
import "./globals.css"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Bitwrap Technologies | Web Development Services",
  description:
    "Take your business to new heights with advanced website development services from Bitwrap Technologies.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
          {children}
          <footer className="bg-[#002642] text-white py-8">
            <div className="container px-4 md:px-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
                <div>
                  <h3 className="font-bold mb-4">Bitwrap</h3>
                  <p className="text-sm text-gray-300">
                    Empowering businesses with innovative web solutions since 2018.
                  </p>
                </div>
                <div>
                  <h3 className="font-bold mb-4">Services</h3>
                  <ul className="space-y-2 text-sm text-gray-300">
                    <li>Web Development</li>
                    <li>E-commerce Solutions</li>
                    <li>Custom Applications</li>
                    <li>UI/UX Design</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-bold mb-4">Company</h3>
                  <ul className="space-y-2 text-sm text-gray-300">
                    <li>About Us</li>
                    <li>Our Team</li>
                    <li>Careers</li>
                    <li>Contact</li>
                  </ul>
                </div>
                <div>
                  <h3 className="font-bold mb-4">Contact</h3>
                  <ul className="space-y-2 text-sm text-gray-300">
                    <li>info@bitwrap.tech</li>
                    <li>+1 (555) 123-4567</li>
                    <li>123 Tech Street, Digital City</li>
                  </ul>
                </div>
              </div>
              <div className="border-t border-gray-700 mt-8 pt-8 text-center text-sm text-gray-400">
                © {new Date().getFullYear()} Bitwrap Technologies. All rights reserved.
              </div>
            </div>
          </footer>
        </ThemeProvider>
      </body>
    </html>
  )
}
