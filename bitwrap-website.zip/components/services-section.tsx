import { ShoppingCart, Users, Layout, Code } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function ServicesSection() {
  return (
    <section className="py-16 md:py-24">
      <div className="container px-4 md:px-6">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="h-0.5 w-6 bg-gray-800"></div>
            <span className="font-medium">Web Development Services</span>
            <div className="h-0.5 w-6 bg-gray-800"></div>
          </div>
          <h2 className="text-3xl md:text-5xl font-bold">
            Empowering <span className="text-amber-800">Brands</span> with{" "}
            <span className="text-orange-500">Captivating Web</span> Experiences
          </h2>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <Card className="bg-[#fdf8f3] border-orange-200 overflow-hidden">
            <CardHeader className="pb-2 pt-6">
              <div className="flex justify-center mb-4">
                <ShoppingCart className="h-16 w-16 text-gray-800" />
              </div>
              <CardTitle className="text-center text-2xl">E-commerce Websites</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-muted-foreground">
                Transforming your online business with customized e-commerce solutions. Our platforms enhance customer
                interaction, optimize operations, and accelerate revenue growth.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-[#fdf8f3] border-orange-200 overflow-hidden">
            <CardHeader className="pb-2 pt-6">
              <div className="flex justify-center mb-4">
                <Users className="h-16 w-16 text-gray-800" />
              </div>
              <CardTitle className="text-center text-2xl">Social Media Websites</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-muted-foreground">
                Create dynamic social media websites that captivate and engage users, fostering brand growth and loyalty
                effortlessly.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-[#fdf8f3] border-orange-200 overflow-hidden">
            <CardHeader className="pb-2 pt-6">
              <div className="flex justify-center mb-4">
                <Layout className="h-16 w-16 text-gray-800" />
              </div>
              <CardTitle className="text-center text-2xl">Landing Websites</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-muted-foreground">
                Designing high-conversion landing pages that attract attention and drive action. Crafted with tailored
                designs to showcase your brand's message and maximize results.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-[#fdf8f3] border-orange-200 overflow-hidden">
            <CardHeader className="pb-2 pt-6">
              <div className="flex justify-center mb-4">
                <Code className="h-16 w-16 text-gray-800" />
              </div>
              <CardTitle className="text-center text-2xl">Custom Websites</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-muted-foreground">
                Building custom websites that are perfectly aligned with your business needs. Our solutions combine
                creativity and functionality to deliver an exceptional user experience.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
