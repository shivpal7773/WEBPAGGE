import Image from "next/image"
import Link from "next/link"

export default function PortfolioSection() {
  const projects = [
    {
      id: 1,
      name: "5g Homes",
      image: "/portfolio/5g-homes.jpg",
      background: "bg-neutral-100",
    },
    {
      id: 2,
      name: "Bayut",
      image: "/portfolio/bayut.jpg",
      background: "bg-green-50",
    },
    {
      id: 3,
      name: "Cold Creekcap",
      image: "/portfolio/cold-creekcap.jpg",
      background: "bg-blue-100",
    },
    {
      id: 4,
      name: "Menissa Caterings",
      image: "/portfolio/menissa.jpg",
      background: "bg-amber-100",
    },
    {
      id: 5,
      name: "Think Reality",
      image: "/portfolio/think-reality.jpg",
      background: "bg-gray-200",
    },
  ]

  return (
    <section className="py-16 md:py-24">
      <div className="container px-4 md:px-6">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="h-0.5 w-6 bg-gray-800"></div>
            <span className="font-medium">Our Portfolio</span>
            <div className="h-0.5 w-6 bg-gray-800"></div>
          </div>
          <h2 className="text-3xl md:text-5xl font-bold">
            Work Speaks <span className="text-amber-800">Volumes:</span>{" "}
            <span className="text-orange-500">Discover Our Projects</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project) => (
            <Link
              href={`/portfolio/${project.id}`}
              key={project.id}
              className="block border border-orange-200 rounded-lg overflow-hidden transition-transform hover:scale-[1.02]"
            >
              <div className={`${project.background} p-4 aspect-video relative`}>
                <Image src={project.image || "/placeholder.svg"} alt={project.name} fill className="object-contain" />
              </div>
              <div className="bg-[#002642] text-white p-4 text-center font-medium text-lg">{project.name}</div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  )
}
