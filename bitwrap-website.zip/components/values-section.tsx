import { Lightbulb, Users, Target, TrendingUp } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export default function ValuesSection() {
  return (
    <section className="py-16 md:py-24 relative overflow-hidden">
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-orange-50/50 to-transparent"></div>
      </div>
      <div className="container px-4 md:px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-5xl font-bold">
            The fire that <span className="text-amber-700">fuels our passion</span>.
          </h2>
          <p className="mt-4 text-lg">At Bitwrap, we believe in the power of:</p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          <Card className="bg-[#fdf8f3] border-orange-200">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-center">
                <CardTitle className="text-2xl">
                  Imagination<span className="text-orange-500">.</span>
                </CardTitle>
                <div className="bg-orange-500 rounded-full p-3">
                  <Lightbulb className="h-6 w-6 text-white" />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We push the limits and dream beyond the conventional, always aiming for excellence.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-[#fdf8f3] border-orange-200">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-center">
                <CardTitle className="text-2xl">
                  Teamwork<span className="text-orange-500">.</span>
                </CardTitle>
                <div className="bg-orange-500 rounded-full p-3">
                  <Users className="h-6 w-6 text-white" />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                We value diverse viewpoints and believe in the power of collective effort to achieve extraordinary
                outcomes.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-[#fdf8f3] border-orange-200">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-center">
                <CardTitle className="text-2xl">
                  Purpose<span className="text-orange-500">.</span>
                </CardTitle>
                <div className="bg-orange-500 rounded-full p-3">
                  <Target className="h-6 w-6 text-white" />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Driven by a passion to make an impact, we create brands that inspire and drive meaningful change.
              </p>
            </CardContent>
          </Card>

          <Card className="bg-[#fdf8f3] border-orange-200">
            <CardHeader className="pb-2">
              <div className="flex justify-between items-center">
                <CardTitle className="text-2xl">
                  Progress<span className="text-orange-500">.</span>
                </CardTitle>
                <div className="bg-orange-500 rounded-full p-3">
                  <TrendingUp className="h-6 w-6 text-white" />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Constantly evolving, we embrace emerging trends and technologies to ensure your brand stays ahead.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
