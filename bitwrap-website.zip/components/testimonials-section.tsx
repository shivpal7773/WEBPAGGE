import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function TestimonialsSection() {
  return (
    <section className="py-16 md:py-24">
      <div className="container px-4 md:px-6">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="h-0.5 w-6 bg-gray-800"></div>
            <span className="font-medium">Testimonials</span>
            <div className="h-0.5 w-6 bg-gray-800"></div>
          </div>
          <h2 className="text-3xl md:text-5xl font-bold">
            What <span className="text-gray-700">Our</span> <span className="text-amber-800">Clients</span>{" "}
            <span className="text-orange-500">Say</span>
          </h2>
        </div>

        <div className="relative">
          <div className="grid md:grid-cols-3 gap-6">
            <Card className="bg-gray-50">
              <CardContent className="pt-6">
                <p className="italic text-center">
                  "Bitwrap's app development team delivered a seamless, feature-rich application, on time and within our
                  budget. A fantastic experience from start to finish!"
                </p>
              </CardContent>
              <CardFooter className="flex flex-col items-center pb-6">
                <Avatar className="h-16 w-16 border-2 border-gray-200 mb-2">
                  <AvatarImage src="/placeholder-user.jpg" alt="Aarav Kapoor" />
                  <AvatarFallback>AK</AvatarFallback>
                </Avatar>
                <div className="text-center">
                  <h4 className="font-semibold">Aarav Kapoor</h4>
                  <p className="text-sm text-muted-foreground">Product Manager at Nexus Tech</p>
                </div>
              </CardFooter>
            </Card>

            <Card className="bg-gray-50">
              <CardContent className="pt-6">
                <p className="italic text-center">
                  "Bitwrap impressed us with their creativity in app development. They flawlessly turned our vision into
                  reality. Exceptional service all around!"
                </p>
              </CardContent>
              <CardFooter className="flex flex-col items-center pb-6">
                <Avatar className="h-16 w-16 border-2 border-gray-200 mb-2">
                  <AvatarImage src="/placeholder-user.jpg" alt="Jessica M" />
                  <AvatarFallback>JM</AvatarFallback>
                </Avatar>
                <div className="text-center">
                  <h4 className="font-semibold">Jessica M</h4>
                  <p className="text-sm text-muted-foreground">COO at Creative Solutions</p>
                </div>
              </CardFooter>
            </Card>

            <Card className="bg-gray-50">
              <CardContent className="pt-6">
                <p className="italic text-center">
                  "Bitwrap's web development services are outstanding. They delivered a responsive and user-friendly
                  site that perfectly captures our brand essence. Excellent work!"
                </p>
              </CardContent>
              <CardFooter className="flex flex-col items-center pb-6">
                <Avatar className="h-16 w-16 border-2 border-gray-200 mb-2">
                  <AvatarImage src="/placeholder-user.jpg" alt="Samiksha Sharma" />
                  <AvatarFallback>SS</AvatarFallback>
                </Avatar>
                <div className="text-center">
                  <h4 className="font-semibold">Samiksha Sharma</h4>
                  <p className="text-sm text-muted-foreground">Operations Manager at EcoFlow Systems</p>
                </div>
              </CardFooter>
            </Card>
          </div>

          <Button
            variant="outline"
            size="icon"
            className="absolute -left-4 top-1/2 -translate-y-1/2 bg-white shadow-md rounded-full hidden md:flex"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="absolute -right-4 top-1/2 -translate-y-1/2 bg-white shadow-md rounded-full hidden md:flex"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </section>
  )
}
