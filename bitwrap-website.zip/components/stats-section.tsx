export default function StatsSection() {
  return (
    <section className="bg-[#002642] text-white py-16">
      <div className="container px-4 md:px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          <div className="space-y-2">
            <h3 className="text-4xl md:text-6xl font-bold text-orange-500">5+</h3>
            <p className="text-lg">Years of Experience</p>
          </div>
          <div className="space-y-2">
            <h3 className="text-4xl md:text-6xl font-bold text-orange-500">25+</h3>
            <p className="text-lg">Expert Team</p>
          </div>
          <div className="space-y-2">
            <h3 className="text-4xl md:text-6xl font-bold text-orange-500">400+</h3>
            <p className="text-lg">Happy Clients</p>
          </div>
          <div className="space-y-2">
            <h3 className="text-4xl md:text-6xl font-bold text-orange-500">500+</h3>
            <p className="text-lg">Projects Completed</p>
          </div>
        </div>
      </div>
    </section>
  )
}
