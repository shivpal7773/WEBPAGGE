import Image from "next/image"

export default function ClientsSection() {
  return (
    <section className="py-16 md:py-24 relative overflow-hidden">
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-orange-50/50 to-transparent"></div>
      </div>
      <div className="container px-4 md:px-6 text-center">
        <h2 className="text-3xl md:text-5xl font-bold mb-16">
          Join Our <span className="text-orange-500">400+</span> Happy Clients
        </h2>

        <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16">
          <div className="bg-white rounded-full px-8 py-4 shadow-sm">
            <Image src="/placeholder-logo.svg" alt="Client Logo" width={120} height={40} />
          </div>
          <div className="bg-white rounded-full px-8 py-4 shadow-sm">
            <Image src="/placeholder-logo.svg" alt="Client Logo" width={120} height={40} />
          </div>
          <div className="bg-white rounded-full px-8 py-4 shadow-sm">
            <Image src="/placeholder-logo.svg" alt="Client Logo" width={120} height={40} />
          </div>
          <div className="bg-white rounded-full px-8 py-4 shadow-sm">
            <Image src="/placeholder-logo.svg" alt="Client Logo" width={120} height={40} />
          </div>
          <div className="bg-white rounded-full px-8 py-4 shadow-sm">
            <Image src="/placeholder-logo.svg" alt="Client Logo" width={120} height={40} />
          </div>
        </div>
      </div>
    </section>
  )
}
