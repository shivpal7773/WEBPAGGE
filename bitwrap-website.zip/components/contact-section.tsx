import { Button } from "@/components/ui/button"

export default function ContactSection() {
  return (
    <section className="py-16 md:py-24">
      <div className="container px-4 md:px-6">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-2 mb-4">
            <div className="h-0.5 w-6 bg-gray-800"></div>
            <span className="font-medium">Contact Us</span>
            <div className="h-0.5 w-6 bg-gray-800"></div>
          </div>
          <h2 className="text-3xl md:text-5xl font-bold">
            Get In <span className="text-amber-800">Touch With</span> <span className="text-orange-500">Us!</span>
          </h2>
          <p className="mt-4 text-lg max-w-3xl mx-auto">
            Together, we'll create innovative solutions that align with your vision, empowering your business to achieve
            greater success.
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          <form className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label htmlFor="name" className="text-sm font-medium">
                  Full Name
                </label>
                <input
                  id="name"
                  placeholder="John Doe"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                />
              </div>
              <div className="space-y-2">
                <label htmlFor="email" className="text-sm font-medium">
                  Email Address
                </label>
                <input
                  id="email"
                  type="email"
                  placeholder="john@example.com"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label htmlFor="subject" className="text-sm font-medium">
                Subject
              </label>
              <input
                id="subject"
                placeholder="How can we help you?"
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="message" className="text-sm font-medium">
                Message
              </label>
              <textarea
                id="message"
                placeholder="Tell us about your project..."
                rows={5}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
              />
            </div>
            <Button className="w-full bg-orange-500 hover:bg-orange-600 text-white">Send Message</Button>
          </form>
        </div>
      </div>
    </section>
  )
}
