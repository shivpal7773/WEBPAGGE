import Image from "next/image"

export default function HeroSection() {
  return (
    <section className="relative overflow-hidden py-20 lg:py-32">
      <div className="absolute inset-0 -z-10">
        <Image src="/circuit-pattern.svg" alt="Background pattern" fill className="object-cover opacity-20" />
      </div>
      <div className="container px-4 md:px-6 text-center">
        <div className="max-w-4xl mx-auto space-y-8">
          <h2 className="text-2xl font-medium">
            Welcome to <span className="font-bold">Bitwrap</span>
          </h2>
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight">
            Take Your Business To New Heights With
            <span className="block">Advanced Website Development</span>
          </h1>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto">
            Revolutionize your business with our state-of-the-art IT services, driving efficiency, agility, and growth
            in today's rapidly evolving digital landscape.
          </p>
        </div>
      </div>
    </section>
  )
}
