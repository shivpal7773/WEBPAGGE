import Image from "next/image"

export default function WebDevelopmentSection() {
  return (
    <section className="py-16 md:py-24">
      <div className="container px-4 md:px-6">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="order-2 md:order-1">
            <Image
              src="/web-design.jpg"
              alt="Web Design Concept"
              width={600}
              height={400}
              className="rounded-lg shadow-lg"
            />
          </div>
          <div className="order-1 md:order-2 space-y-6">
            <div className="flex items-center gap-2">
              <div className="h-0.5 w-6 bg-gray-800"></div>
              <span className="font-medium">Web Development</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold">
              Innovative <span className="text-amber-800">Web Development</span> Solutions for{" "}
              <span className="text-orange-500">Modern Brands</span>
            </h2>
            <p className="text-muted-foreground">
              Your website is more than just a digital space—it's the heart of your brand's online presence. We create
              websites that captivate, convert, and perform flawlessly. With sleek designs and responsive features, we
              build websites that not only look impressive but also deliver outstanding results.
            </p>
            <p className="text-muted-foreground">
              Your website should leave a lasting impression. We specialize in fast, responsive, and visually striking
              websites that reflect your brand's essence and help you achieve your goals. Whether it's an e-commerce
              platform or a custom web app, we've got you covered.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
